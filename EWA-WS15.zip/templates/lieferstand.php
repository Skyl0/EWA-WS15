<div class="contentwrap padding-20">
	<h1>Sehr geehrter Herr/Frau Soundso,</h1>
	<p>hier sehen Sie den Status ihrer Lieferung:</p>
	<div class="content">
		<div class="pizza-item">Pizza Margharita
			<div class="progress">
			<span>In Bearbeitung</span>
			<div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
				<span class="sr-only">In Bearbeitung</span>
			</div>
			</div>
		</div>
		<!-- NEW -->
		<div class="pizza-item">Pizza Tonno
			<div class="progress">
			<span>Bestellt</span>	
			<div class="progress-bar progress-bar-warning progress-bar-striped" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 10%">
				<span class="sr-only">Bestellt</span>
			</div>
			</div>
		</div>
		<!-- NEW -->
		<div class="pizza-item">Pizza Prosciutto
			<div class="progress">
			<span>Fertig</span>
			<div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%">
				<span class="sr-only">Fertig</span>
			</div>
			</div>
		</div>
		<div class="alert alert-info" role="alert">
			Sobald alle Pizzen den Status "fertig" erhalten, wird ihre Sendung dem nächsten freien Fahrer übergeben.<br/>Wir bedanken uns für ihre Geduld.
		</div>
	</div>
</div>
	<div class="contentwrap padding-20">
	<h1>Auswahlmenü</h1>
	<a class="btn-default btn chose" href="index.php?action=Bestellung">Kunde (Bestellung)</a>
	<a class="btn-default btn chose" href="index.php?action=Lieferstand">Kunde (Lieferstand)</a>
	<a class="btn-default btn chose" href="index.php?action=Pizzabaecker">Pizzabäcker (bestellte Pizzen)</a>
	<a class="btn-default btn chose" href="index.php?action=Fahrer">Fahrer (fertige Pizzen)</a>
	</div>
<div class="contentwrap">
	<h1>Fahrer Lieferstand</h1>
	<div class="content">
		<table>

			<tr class="item-11">
				<td colspan="3">
					Schulz, Kasinostraße 5, 13,50 €<br/>
					Margherita, Salami, Tonno
				</td>
				<td><a href="/x.php?value=weiter">Weiter</a></td>
			</tr>
			<tr class="item-11">
				<td>
					fertig<br/><i class="fa fa-icon fertig"></i>
				</td>
				<td>
					unterwegs<br/><i class="fa fa-icon2 unterwegs active"></i>
				</td>
				<td>
					geliefert<br/><i class="fa fa-icon3 geliefert"></i>
				</td>
				<td>
					<a href="/x.php?value=weiter">Zurück</a>
				</td>
			</tr>
			<br/>
			<!-- NEXT ITEM -->
						<tr class="item-11">
				<td colspan="3">
					Müller, Kasinostraße 5, 9,50 €<br/>
					Margherita, Salami
				</td>
				<td><a href="/x.php?value=weiter">Weiter</a></td>
			</tr>
			<tr class="item-11">
				<td>
					fertig<br/><i class="fa fa-icon fertig active"></i>
				</td>
				<td>
					unterwegs<br/><i class="fa fa-icon2 unterwegs"></i>
				</td>
				<td>
					geliefert<br/><i class="fa fa-icon3 geliefert"></i>
				</td>
				<td>
					<a href="/x.php?value=weiter">Zurück</a>
				</td>
			</tr>

		</table>
	</div>
	</div>
<div class="contentwrap padding-20">
	<h1>Fahrer Lieferstand</h1>
	<div class="content">
		<!-- ITEM -->
		<div class="fahrer-item">
			<div class="inhalt"><h3>Schulz, Kasinostraße 5, 13,50 €</h3>
				<p>Margherita, Salami, Tonno</p>
			</div>
			<div class="progress">
				<span>Fertig</span>
				<div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 10%">
					<span class="sr-only">Fertig</span>
				</div>
			</div>
		</div>
		<a href="/echo.php?action=Fahrer&amp;next=1" style="display: inline-block;" class="btn btn-info">Nächster Schritt</a>
		<!-- ITEM -->
		<div class="fahrer-item">
			<div class="inhalt"><h3>Meier, Soderstr 7, 21,50 €</h3>
				<p>Margherita, Salami, Tonno, Salat</p>
			</div>
			<div class="progress">
				<span>In Auslieferung</span>
				<div class="progress-bar progress-bar-warning progress-bar-striped" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
					<span class="sr-only">In Auslieferung</span>
				</div>
			</div>
		</div>
		<a href="/echo.php?action=Fahrer&amp;next=1" style="display: inline-block;" class="btn btn-info">Nächster Schritt</a>
		<!-- ITEM -->
	</div>
</div>

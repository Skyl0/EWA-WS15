<div class="contentwrap">
	<h1>Kunde Lieferstand</h1>
	<div class="content">
		<table>
			<tr>
				<th>
					&nbsp;
				</th>
				<th>
					bestellt
				</th>
				<th>
					im Ofen
				</th>
				<th>
					fertig
				</th>
				<th>
					unterwegs
				</th>
			</tr>
			<tr class="item-11">
				<td>Margherita</td>
				<td>
					<i class="fa fa-icon bestellt active"></i>
				</td>
				<td>
					<i class="fa fa-icon2 im-ofen"></i>
				</td>
				<td>
					<i class="fa fa-icon3 fertig"></i>
				</td>
				<td>
					<i class="fa fa-icon4 unterwegs"></i>
				</td>
			</tr>
						<tr class="item-12">
				<td>Tonno</td>
				<td>
					<i class="fa fa-icon bestellt"></i>
				</td>
				<td>
					<i class="fa fa-icon2 im-ofen active"></i>
				</td>
				<td>
					<i class="fa fa-icon3 fertig"></i>
				</td>
				<td>
					<i class="fa fa-icon4 unterwegs"></i>
				</td>
			</tr>
						<tr class="item-13">
				<td>Prosciutto</td>
				<td>
					<i class="fa fa-icon bestellt"></i>
				</td>
				<td>
					<i class="fa fa-icon2 im-ofen active"></i>
				</td>
				<td>
					<i class="fa fa-icon3 fertig"></i>
				</td>
				<td>
					<i class="fa fa-icon4 unterwegs"></i>
				</td>
			</tr>
		</table>
	</div></div>
<?php
/*
 * Template for Footer
 * Pizzadienst EWA WS15
 */ 
 ?><div class="footer">
		<span class="glyphicon glyphicon-copyright-mark grey" aria-hidden="true"></span> by <a href="http://www.skyit-webdesign.com" target="_blank">Marc Ernst</a> <span class="grey">[</span> 738702 <span class="grey">]</span> - Contact <a href="mailto:ernst.marc@gmail.com">M.E.<span class="glyphicon glyphicon-envelope"></span></a> - In Corporation with <a href="http://www.fbi.h-da.de" target="_blank">fbi h-da</a> - 2015/2016
	</div>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>